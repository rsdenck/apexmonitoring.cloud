# agent/task_base.py - Exemplo de conteúdo ZSH para infra_agent
