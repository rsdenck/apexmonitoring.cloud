# agent/config.py - Exemplo de conteúdo ZSH para infra_agent
