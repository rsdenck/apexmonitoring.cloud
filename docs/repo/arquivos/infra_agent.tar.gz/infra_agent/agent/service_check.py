# agent/service_check.py - Exemplo de conteúdo ZSH para infra_agent
