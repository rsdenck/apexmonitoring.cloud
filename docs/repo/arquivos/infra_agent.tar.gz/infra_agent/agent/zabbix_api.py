# agent/zabbix_api.py - Exemplo de conteúdo ZSH para infra_agent
