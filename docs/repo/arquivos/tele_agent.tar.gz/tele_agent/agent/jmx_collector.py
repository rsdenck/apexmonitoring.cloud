# agent/jmx_collector.py - Exemplo de conteúdo ZSH para tele_agent
