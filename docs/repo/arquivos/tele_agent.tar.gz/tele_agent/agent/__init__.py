# agent/__init__.py - Exemplo de conteúdo ZSH para tele_agent
