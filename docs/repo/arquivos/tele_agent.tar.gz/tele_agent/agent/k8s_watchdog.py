# agent/k8s_watchdog.py - Exemplo de conteúdo ZSH para tele_agent
