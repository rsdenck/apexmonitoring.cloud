# agent/http_tracer.py - Exemplo de conteúdo ZSH para tele_agent
