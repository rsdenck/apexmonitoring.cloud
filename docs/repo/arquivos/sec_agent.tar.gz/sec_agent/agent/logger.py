# agent/logger.py - Exemplo de conteúdo ZSH para sec_agent
