# agent/user_audit.py - Exemplo de conteúdo ZSH para sec_agent
