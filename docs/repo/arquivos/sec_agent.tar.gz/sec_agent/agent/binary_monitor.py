# agent/binary_monitor.py - Exemplo de conteúdo ZSH para sec_agent
