# agent/network_check.py - Exemplo de conteúdo ZSH para sec_agent
